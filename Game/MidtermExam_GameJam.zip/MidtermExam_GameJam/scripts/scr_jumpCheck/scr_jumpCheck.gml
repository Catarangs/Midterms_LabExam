function scr_jumpCheck(){
	if (jumping){
		if (v_spd<0)
		jumping=true
	}
	else{
		jumping=false
		falling=true
	}
}