function scr_ground_check(){
	if (duck_key){
		jumping=false
		falling=false
		ducking=true
	}
	
	if (place_meeting(x,y+1,obj_wall)){
		v_spd=0
		jumping=false
		falling=false
		
		if (!duck_key){
			ducking=false
		}
		
		if ((jump_key) && !ducking){
			
			jumping=true
			v_spd= -jump_Spd
		}
	}
	 else {
		if (ducking){
			v_spd +=grav * 4
		} 
		else {
			if (v_spd <termVelocity){
			v_spd += grav
			}
			if (sign(v_spd) ==1){
			falling=true
			}
		}
	}
}