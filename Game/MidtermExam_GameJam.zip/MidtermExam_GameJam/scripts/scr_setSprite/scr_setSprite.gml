function scr_setSprite(){
	if(jumping || falling){
		sprite_index=spr_Player_jump
	}
	
	if (ducking){
		sprite_index=spr_Player_duck
	}
	
	if(!jumping && !falling && !ducking){
		sprite_index=spr_Player_run
	}
}