if (!global.game_over && spawning){
	var o = instance_create_layer(room_width + 32, 0, "Player", obj_obstacle)
	o.y = 448 - o.sprite_height
}
alarm[0] = irandom_range(50, 110)
