//initial 
mask_index=spr_Player_run
grav=7
jump_Spd=50
v_spd=0
termVelocity=50



//status
jumping=false
falling=false
ducking=false
